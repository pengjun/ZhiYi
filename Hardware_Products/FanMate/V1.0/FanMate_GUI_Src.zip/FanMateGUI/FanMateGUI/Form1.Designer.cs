﻿namespace FanMateGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel251 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel252 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel253 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel254 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel255 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel256 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel257 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel258 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel259 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel260 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel261 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel262 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel263 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel264 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel265 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel266 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel267 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel268 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel269 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel270 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel271 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel272 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel273 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel274 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel275 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel276 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel277 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel278 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel279 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel280 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel281 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel282 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel283 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel284 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel285 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel286 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel287 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel288 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel289 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel290 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel291 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel292 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel293 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel294 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel295 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel296 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel297 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel298 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel299 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel300 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel301 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel302 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel303 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel304 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel305 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel306 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel307 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel308 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel309 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel310 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel311 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel312 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel313 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel314 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel315 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel316 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel317 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel318 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel319 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel320 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel321 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel322 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel323 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel324 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel325 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel326 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel327 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel328 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel329 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel330 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel331 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel332 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel333 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel334 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel335 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel336 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel337 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel338 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel339 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel340 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel341 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel342 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel343 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel344 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel345 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel346 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel347 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel348 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel349 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel350 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel351 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel1 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel2 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel3 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel4 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel5 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel6 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel7 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel8 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel9 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel10 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel11 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel12 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel13 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel14 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel15 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel16 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel17 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel18 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel19 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel20 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel21 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel22 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel23 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel24 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel25 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel26 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel27 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel28 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel29 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel30 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel31 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel32 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel33 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel34 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel35 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel36 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel37 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel38 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel39 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel40 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel41 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel42 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel43 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel44 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel45 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel46 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel47 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel48 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel49 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel50 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel51 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel52 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel53 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel54 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel55 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel56 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel57 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel58 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel59 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel60 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel61 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel62 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel63 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel64 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel65 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel66 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel67 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel68 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel69 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel70 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel71 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel72 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel73 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel74 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel75 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel76 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel77 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel78 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel79 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel80 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel81 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel82 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel83 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel84 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel85 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel86 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel87 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel88 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel89 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel90 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel91 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel92 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel93 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel94 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel95 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel96 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel97 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel98 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel99 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel100 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel101 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel102 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel103 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel104 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel105 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel106 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel107 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel108 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel109 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel110 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel111 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel112 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel113 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel114 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel115 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel116 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel117 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel118 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel119 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel120 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel121 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel122 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel123 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel124 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel125 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel126 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel127 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel128 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel129 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel130 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel131 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel132 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel133 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel134 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel135 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel136 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel137 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel138 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel139 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel140 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel141 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel142 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel143 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel144 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel145 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel146 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel147 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel148 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel149 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel150 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel151 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel152 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel153 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel154 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel155 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel156 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel157 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel158 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel159 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel160 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel161 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel162 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel163 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel164 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel165 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel166 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel167 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel168 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel169 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel170 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel171 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel172 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel173 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel174 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel175 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel176 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel177 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel178 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel179 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel180 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel181 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel182 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel183 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel184 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel185 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel186 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel187 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel188 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel189 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel190 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel191 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel192 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel193 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel194 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel195 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel196 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel197 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel198 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel199 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel200 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel201 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel202 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel203 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel204 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel205 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel206 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel207 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel208 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel209 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel210 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel211 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel212 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel213 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel214 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel215 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel216 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel217 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel218 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel219 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel220 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel221 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel222 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel223 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel224 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel225 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel226 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel227 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel228 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel229 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel230 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel231 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel232 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel233 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel234 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel235 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel236 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel237 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel238 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel239 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel240 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel241 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel242 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel243 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel244 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel245 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel246 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel247 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel248 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel249 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            DevExpress.XtraEditors.Repository.TrackBarLabel trackBarLabel250 = new DevExpress.XtraEditors.Repository.TrackBarLabel();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.bar1 = new DevExpress.XtraBars.Bar();
            this.barSubItem2 = new DevExpress.XtraBars.BarSubItem();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.chartControl1 = new DevExpress.XtraCharts.ChartControl();
            this.gaugeControl1 = new DevExpress.XtraGauges.Win.GaugeControl();
            this.digitalGauge6 = new DevExpress.XtraGauges.Win.Gauges.Digital.DigitalGauge();
            this.digitalBackgroundLayerComponent1 = new DevExpress.XtraGauges.Win.Gauges.Digital.DigitalBackgroundLayerComponent();
            this.trackBarControl1 = new DevExpress.XtraEditors.TrackBarControl();
            this.trackBarControl2 = new DevExpress.XtraEditors.TrackBarControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.digitalGauge6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.digitalBackgroundLayerComponent1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarControl1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarControl2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarControl2.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // barManager1
            // 
            this.barManager1.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar1});
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barSubItem2});
            this.barManager1.MainMenu = this.bar1;
            this.barManager1.MaxItemId = 2;
            // 
            // bar1
            // 
            this.bar1.BarName = "Custom 2";
            this.bar1.DockCol = 0;
            this.bar1.DockRow = 0;
            this.bar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.bar1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barSubItem2)});
            this.bar1.OptionsBar.MultiLine = true;
            this.bar1.OptionsBar.UseWholeRow = true;
            this.bar1.Text = "Custom 2";
            // 
            // barSubItem2
            // 
            this.barSubItem2.Caption = "端口设定";
            this.barSubItem2.Id = 1;
            this.barSubItem2.Name = "barSubItem2";
            this.barSubItem2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barSubItem2_ItemClick);
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Manager = this.barManager1;
            this.barDockControlTop.Size = new System.Drawing.Size(795, 24);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 373);
            this.barDockControlBottom.Manager = this.barManager1;
            this.barDockControlBottom.Size = new System.Drawing.Size(795, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 24);
            this.barDockControlLeft.Manager = this.barManager1;
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 349);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(795, 24);
            this.barDockControlRight.Manager = this.barManager1;
            this.barDockControlRight.Size = new System.Drawing.Size(0, 349);
            // 
            // chartControl1
            // 
            this.chartControl1.Legend.Name = "Default Legend";
            this.chartControl1.Location = new System.Drawing.Point(12, 135);
            this.chartControl1.Name = "chartControl1";
            this.chartControl1.SeriesSerializable = new DevExpress.XtraCharts.Series[0];
            this.chartControl1.Size = new System.Drawing.Size(766, 226);
            this.chartControl1.TabIndex = 4;
            // 
            // gaugeControl1
            // 
            this.gaugeControl1.Gauges.AddRange(new DevExpress.XtraGauges.Base.IGauge[] {
            this.digitalGauge6});
            this.gaugeControl1.Location = new System.Drawing.Point(12, 30);
            this.gaugeControl1.Name = "gaugeControl1";
            this.gaugeControl1.Size = new System.Drawing.Size(250, 98);
            this.gaugeControl1.TabIndex = 5;
            // 
            // digitalGauge6
            // 
            this.digitalGauge6.AppearanceOff.ContentBrush = new DevExpress.XtraGauges.Core.Drawing.SolidBrushObject("Color:#EEECDF");
            this.digitalGauge6.AppearanceOn.ContentBrush = new DevExpress.XtraGauges.Core.Drawing.SolidBrushObject("Color:#524E48");
            this.digitalGauge6.BackgroundLayers.AddRange(new DevExpress.XtraGauges.Win.Gauges.Digital.DigitalBackgroundLayerComponent[] {
            this.digitalBackgroundLayerComponent1});
            this.digitalGauge6.Bounds = new System.Drawing.Rectangle(6, 6, 238, 86);
            this.digitalGauge6.DigitCount = 5;
            this.digitalGauge6.Name = "digitalGauge6";
            this.digitalGauge6.Padding = new DevExpress.XtraGauges.Core.Base.TextSpacing(26, 20, 26, 20);
            this.digitalGauge6.Text = "00000";
            // 
            // digitalBackgroundLayerComponent1
            // 
            this.digitalBackgroundLayerComponent1.BottomRight = new DevExpress.XtraGauges.Core.Base.PointF2D(265.8125F, 99.9625F);
            this.digitalBackgroundLayerComponent1.Name = "digitalBackgroundLayerComponent1";
            this.digitalBackgroundLayerComponent1.ShapeType = DevExpress.XtraGauges.Core.Model.DigitalBackgroundShapeSetType.Style20;
            this.digitalBackgroundLayerComponent1.TopLeft = new DevExpress.XtraGauges.Core.Base.PointF2D(26F, 0F);
            this.digitalBackgroundLayerComponent1.ZOrder = 1000;
            // 
            // trackBarControl1
            // 
            this.trackBarControl1.EditValue = null;
            this.trackBarControl1.Location = new System.Drawing.Point(312, 30);
            this.trackBarControl1.MenuManager = this.barManager1;
            this.trackBarControl1.Name = "trackBarControl1";
            this.trackBarControl1.Properties.AutoSize = false;
            this.trackBarControl1.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.trackBarControl1.Properties.LabelAppearance.Options.UseTextOptions = true;
            this.trackBarControl1.Properties.LabelAppearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            trackBarLabel251.Label = "0";
            trackBarLabel252.Label = "1";
            trackBarLabel252.Value = 1;
            trackBarLabel253.Label = "2";
            trackBarLabel253.Value = 2;
            trackBarLabel254.Label = "3";
            trackBarLabel254.Value = 3;
            trackBarLabel255.Label = "4";
            trackBarLabel255.Value = 4;
            trackBarLabel256.Label = "5";
            trackBarLabel256.Value = 5;
            trackBarLabel257.Label = "6";
            trackBarLabel257.Value = 6;
            trackBarLabel258.Label = "7";
            trackBarLabel258.Value = 7;
            trackBarLabel259.Label = "8";
            trackBarLabel259.Value = 8;
            trackBarLabel260.Label = "9";
            trackBarLabel260.Value = 9;
            trackBarLabel261.Label = "10";
            trackBarLabel261.Value = 10;
            trackBarLabel262.Label = "11";
            trackBarLabel262.Value = 11;
            trackBarLabel263.Label = "12";
            trackBarLabel263.Value = 12;
            trackBarLabel264.Label = "13";
            trackBarLabel264.Value = 13;
            trackBarLabel265.Label = "14";
            trackBarLabel265.Value = 14;
            trackBarLabel266.Label = "15";
            trackBarLabel266.Value = 15;
            trackBarLabel267.Label = "16";
            trackBarLabel267.Value = 16;
            trackBarLabel268.Label = "17";
            trackBarLabel268.Value = 17;
            trackBarLabel269.Label = "18";
            trackBarLabel269.Value = 18;
            trackBarLabel270.Label = "19";
            trackBarLabel270.Value = 19;
            trackBarLabel271.Label = "20";
            trackBarLabel271.Value = 20;
            trackBarLabel272.Label = "21";
            trackBarLabel272.Value = 21;
            trackBarLabel273.Label = "22";
            trackBarLabel273.Value = 22;
            trackBarLabel274.Label = "23";
            trackBarLabel274.Value = 23;
            trackBarLabel275.Label = "24";
            trackBarLabel275.Value = 24;
            trackBarLabel276.Label = "25";
            trackBarLabel276.Value = 25;
            trackBarLabel277.Label = "26";
            trackBarLabel277.Value = 26;
            trackBarLabel278.Label = "27";
            trackBarLabel278.Value = 27;
            trackBarLabel279.Label = "28";
            trackBarLabel279.Value = 28;
            trackBarLabel280.Label = "29";
            trackBarLabel280.Value = 29;
            trackBarLabel281.Label = "30";
            trackBarLabel281.Value = 30;
            trackBarLabel282.Label = "31";
            trackBarLabel282.Value = 31;
            trackBarLabel283.Label = "32";
            trackBarLabel283.Value = 32;
            trackBarLabel284.Label = "33";
            trackBarLabel284.Value = 33;
            trackBarLabel285.Label = "34";
            trackBarLabel285.Value = 34;
            trackBarLabel286.Label = "35";
            trackBarLabel286.Value = 35;
            trackBarLabel287.Label = "36";
            trackBarLabel287.Value = 36;
            trackBarLabel288.Label = "37";
            trackBarLabel288.Value = 37;
            trackBarLabel289.Label = "38";
            trackBarLabel289.Value = 38;
            trackBarLabel290.Label = "39";
            trackBarLabel290.Value = 39;
            trackBarLabel291.Label = "40";
            trackBarLabel291.Value = 40;
            trackBarLabel292.Label = "41";
            trackBarLabel292.Value = 41;
            trackBarLabel293.Label = "42";
            trackBarLabel293.Value = 42;
            trackBarLabel294.Label = "43";
            trackBarLabel294.Value = 43;
            trackBarLabel295.Label = "44";
            trackBarLabel295.Value = 44;
            trackBarLabel296.Label = "45";
            trackBarLabel296.Value = 45;
            trackBarLabel297.Label = "46";
            trackBarLabel297.Value = 46;
            trackBarLabel298.Label = "47";
            trackBarLabel298.Value = 47;
            trackBarLabel299.Label = "48";
            trackBarLabel299.Value = 48;
            trackBarLabel300.Label = "49";
            trackBarLabel300.Value = 49;
            trackBarLabel301.Label = "50";
            trackBarLabel301.Value = 50;
            trackBarLabel302.Label = "51";
            trackBarLabel302.Value = 51;
            trackBarLabel303.Label = "52";
            trackBarLabel303.Value = 52;
            trackBarLabel304.Label = "53";
            trackBarLabel304.Value = 53;
            trackBarLabel305.Label = "54";
            trackBarLabel305.Value = 54;
            trackBarLabel306.Label = "55";
            trackBarLabel306.Value = 55;
            trackBarLabel307.Label = "56";
            trackBarLabel307.Value = 56;
            trackBarLabel308.Label = "57";
            trackBarLabel308.Value = 57;
            trackBarLabel309.Label = "58";
            trackBarLabel309.Value = 58;
            trackBarLabel310.Label = "59";
            trackBarLabel310.Value = 59;
            trackBarLabel311.Label = "60";
            trackBarLabel311.Value = 60;
            trackBarLabel312.Label = "61";
            trackBarLabel312.Value = 61;
            trackBarLabel313.Label = "62";
            trackBarLabel313.Value = 62;
            trackBarLabel314.Label = "63";
            trackBarLabel314.Value = 63;
            trackBarLabel315.Label = "64";
            trackBarLabel315.Value = 64;
            trackBarLabel316.Label = "65";
            trackBarLabel316.Value = 65;
            trackBarLabel317.Label = "66";
            trackBarLabel317.Value = 66;
            trackBarLabel318.Label = "67";
            trackBarLabel318.Value = 67;
            trackBarLabel319.Label = "68";
            trackBarLabel319.Value = 68;
            trackBarLabel320.Label = "69";
            trackBarLabel320.Value = 69;
            trackBarLabel321.Label = "70";
            trackBarLabel321.Value = 70;
            trackBarLabel322.Label = "71";
            trackBarLabel322.Value = 71;
            trackBarLabel323.Label = "72";
            trackBarLabel323.Value = 72;
            trackBarLabel324.Label = "73";
            trackBarLabel324.Value = 73;
            trackBarLabel325.Label = "74";
            trackBarLabel325.Value = 74;
            trackBarLabel326.Label = "75";
            trackBarLabel326.Value = 75;
            trackBarLabel327.Label = "76";
            trackBarLabel327.Value = 76;
            trackBarLabel328.Label = "77";
            trackBarLabel328.Value = 77;
            trackBarLabel329.Label = "78";
            trackBarLabel329.Value = 78;
            trackBarLabel330.Label = "79";
            trackBarLabel330.Value = 79;
            trackBarLabel331.Label = "80";
            trackBarLabel331.Value = 80;
            trackBarLabel332.Label = "81";
            trackBarLabel332.Value = 81;
            trackBarLabel333.Label = "82";
            trackBarLabel333.Value = 82;
            trackBarLabel334.Label = "83";
            trackBarLabel334.Value = 83;
            trackBarLabel335.Label = "84";
            trackBarLabel335.Value = 84;
            trackBarLabel336.Label = "85";
            trackBarLabel336.Value = 85;
            trackBarLabel337.Label = "86";
            trackBarLabel337.Value = 86;
            trackBarLabel338.Label = "87";
            trackBarLabel338.Value = 87;
            trackBarLabel339.Label = "88";
            trackBarLabel339.Value = 88;
            trackBarLabel340.Label = "89";
            trackBarLabel340.Value = 89;
            trackBarLabel341.Label = "90";
            trackBarLabel341.Value = 90;
            trackBarLabel342.Label = "91";
            trackBarLabel342.Value = 91;
            trackBarLabel343.Label = "92";
            trackBarLabel343.Value = 92;
            trackBarLabel344.Label = "93";
            trackBarLabel344.Value = 93;
            trackBarLabel345.Label = "94";
            trackBarLabel345.Value = 94;
            trackBarLabel346.Label = "95";
            trackBarLabel346.Value = 95;
            trackBarLabel347.Label = "96";
            trackBarLabel347.Value = 96;
            trackBarLabel348.Label = "97";
            trackBarLabel348.Value = 97;
            trackBarLabel349.Label = "98";
            trackBarLabel349.Value = 98;
            trackBarLabel350.Label = "99";
            trackBarLabel350.Value = 99;
            trackBarLabel351.Label = "100";
            trackBarLabel351.Value = 100;
            this.trackBarControl1.Properties.Labels.AddRange(new DevExpress.XtraEditors.Repository.TrackBarLabel[] {
            trackBarLabel251,
            trackBarLabel252,
            trackBarLabel253,
            trackBarLabel254,
            trackBarLabel255,
            trackBarLabel256,
            trackBarLabel257,
            trackBarLabel258,
            trackBarLabel259,
            trackBarLabel260,
            trackBarLabel261,
            trackBarLabel262,
            trackBarLabel263,
            trackBarLabel264,
            trackBarLabel265,
            trackBarLabel266,
            trackBarLabel267,
            trackBarLabel268,
            trackBarLabel269,
            trackBarLabel270,
            trackBarLabel271,
            trackBarLabel272,
            trackBarLabel273,
            trackBarLabel274,
            trackBarLabel275,
            trackBarLabel276,
            trackBarLabel277,
            trackBarLabel278,
            trackBarLabel279,
            trackBarLabel280,
            trackBarLabel281,
            trackBarLabel282,
            trackBarLabel283,
            trackBarLabel284,
            trackBarLabel285,
            trackBarLabel286,
            trackBarLabel287,
            trackBarLabel288,
            trackBarLabel289,
            trackBarLabel290,
            trackBarLabel291,
            trackBarLabel292,
            trackBarLabel293,
            trackBarLabel294,
            trackBarLabel295,
            trackBarLabel296,
            trackBarLabel297,
            trackBarLabel298,
            trackBarLabel299,
            trackBarLabel300,
            trackBarLabel301,
            trackBarLabel302,
            trackBarLabel303,
            trackBarLabel304,
            trackBarLabel305,
            trackBarLabel306,
            trackBarLabel307,
            trackBarLabel308,
            trackBarLabel309,
            trackBarLabel310,
            trackBarLabel311,
            trackBarLabel312,
            trackBarLabel313,
            trackBarLabel314,
            trackBarLabel315,
            trackBarLabel316,
            trackBarLabel317,
            trackBarLabel318,
            trackBarLabel319,
            trackBarLabel320,
            trackBarLabel321,
            trackBarLabel322,
            trackBarLabel323,
            trackBarLabel324,
            trackBarLabel325,
            trackBarLabel326,
            trackBarLabel327,
            trackBarLabel328,
            trackBarLabel329,
            trackBarLabel330,
            trackBarLabel331,
            trackBarLabel332,
            trackBarLabel333,
            trackBarLabel334,
            trackBarLabel335,
            trackBarLabel336,
            trackBarLabel337,
            trackBarLabel338,
            trackBarLabel339,
            trackBarLabel340,
            trackBarLabel341,
            trackBarLabel342,
            trackBarLabel343,
            trackBarLabel344,
            trackBarLabel345,
            trackBarLabel346,
            trackBarLabel347,
            trackBarLabel348,
            trackBarLabel349,
            trackBarLabel350,
            trackBarLabel351});
            this.trackBarControl1.Properties.Maximum = 100;
            this.trackBarControl1.Properties.ShowLabels = true;
            this.trackBarControl1.Properties.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBarControl1.Size = new System.Drawing.Size(418, 45);
            this.trackBarControl1.TabIndex = 6;
            this.trackBarControl1.EditValueChanged += new System.EventHandler(this.trackBarControl1_EditValueChanged);
            // 
            // trackBarControl2
            // 
            this.trackBarControl2.EditValue = 1;
            this.trackBarControl2.Location = new System.Drawing.Point(312, 79);
            this.trackBarControl2.MenuManager = this.barManager1;
            this.trackBarControl2.Name = "trackBarControl2";
            this.trackBarControl2.Properties.AutoSize = false;
            this.trackBarControl2.Properties.LabelAppearance.Options.UseTextOptions = true;
            this.trackBarControl2.Properties.LabelAppearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            trackBarLabel1.Label = "1";
            trackBarLabel1.Value = 1;
            trackBarLabel2.Label = "2";
            trackBarLabel2.Value = 2;
            trackBarLabel3.Label = "3";
            trackBarLabel3.Value = 3;
            trackBarLabel4.Label = "4";
            trackBarLabel4.Value = 4;
            trackBarLabel5.Label = "5";
            trackBarLabel5.Value = 5;
            trackBarLabel6.Label = "6";
            trackBarLabel6.Value = 6;
            trackBarLabel7.Label = "7";
            trackBarLabel7.Value = 7;
            trackBarLabel8.Label = "8";
            trackBarLabel8.Value = 8;
            trackBarLabel9.Label = "9";
            trackBarLabel9.Value = 9;
            trackBarLabel10.Label = "10";
            trackBarLabel10.Value = 10;
            trackBarLabel11.Label = "11";
            trackBarLabel11.Value = 11;
            trackBarLabel12.Label = "12";
            trackBarLabel12.Value = 12;
            trackBarLabel13.Label = "13";
            trackBarLabel13.Value = 13;
            trackBarLabel14.Label = "14";
            trackBarLabel14.Value = 14;
            trackBarLabel15.Label = "15";
            trackBarLabel15.Value = 15;
            trackBarLabel16.Label = "16";
            trackBarLabel16.Value = 16;
            trackBarLabel17.Label = "17";
            trackBarLabel17.Value = 17;
            trackBarLabel18.Label = "18";
            trackBarLabel18.Value = 18;
            trackBarLabel19.Label = "19";
            trackBarLabel19.Value = 19;
            trackBarLabel20.Label = "20";
            trackBarLabel20.Value = 20;
            trackBarLabel21.Label = "21";
            trackBarLabel21.Value = 21;
            trackBarLabel22.Label = "22";
            trackBarLabel22.Value = 22;
            trackBarLabel23.Label = "23";
            trackBarLabel23.Value = 23;
            trackBarLabel24.Label = "24";
            trackBarLabel24.Value = 24;
            trackBarLabel25.Label = "25";
            trackBarLabel25.Value = 25;
            trackBarLabel26.Label = "26";
            trackBarLabel26.Value = 26;
            trackBarLabel27.Label = "27";
            trackBarLabel27.Value = 27;
            trackBarLabel28.Label = "28";
            trackBarLabel28.Value = 28;
            trackBarLabel29.Label = "29";
            trackBarLabel29.Value = 29;
            trackBarLabel30.Label = "30";
            trackBarLabel30.Value = 30;
            trackBarLabel31.Label = "31";
            trackBarLabel31.Value = 31;
            trackBarLabel32.Label = "32";
            trackBarLabel32.Value = 32;
            trackBarLabel33.Label = "33";
            trackBarLabel33.Value = 33;
            trackBarLabel34.Label = "34";
            trackBarLabel34.Value = 34;
            trackBarLabel35.Label = "35";
            trackBarLabel35.Value = 35;
            trackBarLabel36.Label = "36";
            trackBarLabel36.Value = 36;
            trackBarLabel37.Label = "37";
            trackBarLabel37.Value = 37;
            trackBarLabel38.Label = "38";
            trackBarLabel38.Value = 38;
            trackBarLabel39.Label = "39";
            trackBarLabel39.Value = 39;
            trackBarLabel40.Label = "40";
            trackBarLabel40.Value = 40;
            trackBarLabel41.Label = "41";
            trackBarLabel41.Value = 41;
            trackBarLabel42.Label = "42";
            trackBarLabel42.Value = 42;
            trackBarLabel43.Label = "43";
            trackBarLabel43.Value = 43;
            trackBarLabel44.Label = "44";
            trackBarLabel44.Value = 44;
            trackBarLabel45.Label = "45";
            trackBarLabel45.Value = 45;
            trackBarLabel46.Label = "46";
            trackBarLabel46.Value = 46;
            trackBarLabel47.Label = "47";
            trackBarLabel47.Value = 47;
            trackBarLabel48.Label = "48";
            trackBarLabel48.Value = 48;
            trackBarLabel49.Label = "49";
            trackBarLabel49.Value = 49;
            trackBarLabel50.Label = "50";
            trackBarLabel50.Value = 50;
            trackBarLabel51.Label = "51";
            trackBarLabel51.Value = 51;
            trackBarLabel52.Label = "52";
            trackBarLabel52.Value = 52;
            trackBarLabel53.Label = "53";
            trackBarLabel53.Value = 53;
            trackBarLabel54.Label = "54";
            trackBarLabel54.Value = 54;
            trackBarLabel55.Label = "55";
            trackBarLabel55.Value = 55;
            trackBarLabel56.Label = "56";
            trackBarLabel56.Value = 56;
            trackBarLabel57.Label = "57";
            trackBarLabel57.Value = 57;
            trackBarLabel58.Label = "58";
            trackBarLabel58.Value = 58;
            trackBarLabel59.Label = "59";
            trackBarLabel59.Value = 59;
            trackBarLabel60.Label = "60";
            trackBarLabel60.Value = 60;
            trackBarLabel61.Label = "61";
            trackBarLabel61.Value = 61;
            trackBarLabel62.Label = "62";
            trackBarLabel62.Value = 62;
            trackBarLabel63.Label = "63";
            trackBarLabel63.Value = 63;
            trackBarLabel64.Label = "64";
            trackBarLabel64.Value = 64;
            trackBarLabel65.Label = "65";
            trackBarLabel65.Value = 65;
            trackBarLabel66.Label = "66";
            trackBarLabel66.Value = 66;
            trackBarLabel67.Label = "67";
            trackBarLabel67.Value = 67;
            trackBarLabel68.Label = "68";
            trackBarLabel68.Value = 68;
            trackBarLabel69.Label = "69";
            trackBarLabel69.Value = 69;
            trackBarLabel70.Label = "70";
            trackBarLabel70.Value = 70;
            trackBarLabel71.Label = "71";
            trackBarLabel71.Value = 71;
            trackBarLabel72.Label = "72";
            trackBarLabel72.Value = 72;
            trackBarLabel73.Label = "73";
            trackBarLabel73.Value = 73;
            trackBarLabel74.Label = "74";
            trackBarLabel74.Value = 74;
            trackBarLabel75.Label = "75";
            trackBarLabel75.Value = 75;
            trackBarLabel76.Label = "76";
            trackBarLabel76.Value = 76;
            trackBarLabel77.Label = "77";
            trackBarLabel77.Value = 77;
            trackBarLabel78.Label = "78";
            trackBarLabel78.Value = 78;
            trackBarLabel79.Label = "79";
            trackBarLabel79.Value = 79;
            trackBarLabel80.Label = "80";
            trackBarLabel80.Value = 80;
            trackBarLabel81.Label = "81";
            trackBarLabel81.Value = 81;
            trackBarLabel82.Label = "82";
            trackBarLabel82.Value = 82;
            trackBarLabel83.Label = "83";
            trackBarLabel83.Value = 83;
            trackBarLabel84.Label = "84";
            trackBarLabel84.Value = 84;
            trackBarLabel85.Label = "85";
            trackBarLabel85.Value = 85;
            trackBarLabel86.Label = "86";
            trackBarLabel86.Value = 86;
            trackBarLabel87.Label = "87";
            trackBarLabel87.Value = 87;
            trackBarLabel88.Label = "88";
            trackBarLabel88.Value = 88;
            trackBarLabel89.Label = "89";
            trackBarLabel89.Value = 89;
            trackBarLabel90.Label = "90";
            trackBarLabel90.Value = 90;
            trackBarLabel91.Label = "91";
            trackBarLabel91.Value = 91;
            trackBarLabel92.Label = "92";
            trackBarLabel92.Value = 92;
            trackBarLabel93.Label = "93";
            trackBarLabel93.Value = 93;
            trackBarLabel94.Label = "94";
            trackBarLabel94.Value = 94;
            trackBarLabel95.Label = "95";
            trackBarLabel95.Value = 95;
            trackBarLabel96.Label = "96";
            trackBarLabel96.Value = 96;
            trackBarLabel97.Label = "97";
            trackBarLabel97.Value = 97;
            trackBarLabel98.Label = "98";
            trackBarLabel98.Value = 98;
            trackBarLabel99.Label = "99";
            trackBarLabel99.Value = 99;
            trackBarLabel100.Label = "100";
            trackBarLabel100.Value = 100;
            trackBarLabel101.Label = "101";
            trackBarLabel101.Value = 101;
            trackBarLabel102.Label = "102";
            trackBarLabel102.Value = 102;
            trackBarLabel103.Label = "103";
            trackBarLabel103.Value = 103;
            trackBarLabel104.Label = "104";
            trackBarLabel104.Value = 104;
            trackBarLabel105.Label = "105";
            trackBarLabel105.Value = 105;
            trackBarLabel106.Label = "106";
            trackBarLabel106.Value = 106;
            trackBarLabel107.Label = "107";
            trackBarLabel107.Value = 107;
            trackBarLabel108.Label = "108";
            trackBarLabel108.Value = 108;
            trackBarLabel109.Label = "109";
            trackBarLabel109.Value = 109;
            trackBarLabel110.Label = "110";
            trackBarLabel110.Value = 110;
            trackBarLabel111.Label = "111";
            trackBarLabel111.Value = 111;
            trackBarLabel112.Label = "112";
            trackBarLabel112.Value = 112;
            trackBarLabel113.Label = "113";
            trackBarLabel113.Value = 113;
            trackBarLabel114.Label = "114";
            trackBarLabel114.Value = 114;
            trackBarLabel115.Label = "115";
            trackBarLabel115.Value = 115;
            trackBarLabel116.Label = "116";
            trackBarLabel116.Value = 116;
            trackBarLabel117.Label = "117";
            trackBarLabel117.Value = 117;
            trackBarLabel118.Label = "118";
            trackBarLabel118.Value = 118;
            trackBarLabel119.Label = "119";
            trackBarLabel119.Value = 119;
            trackBarLabel120.Label = "120";
            trackBarLabel120.Value = 120;
            trackBarLabel121.Label = "121";
            trackBarLabel121.Value = 121;
            trackBarLabel122.Label = "122";
            trackBarLabel122.Value = 122;
            trackBarLabel123.Label = "123";
            trackBarLabel123.Value = 123;
            trackBarLabel124.Label = "124";
            trackBarLabel124.Value = 124;
            trackBarLabel125.Label = "125";
            trackBarLabel125.Value = 125;
            trackBarLabel126.Label = "126";
            trackBarLabel126.Value = 126;
            trackBarLabel127.Label = "127";
            trackBarLabel127.Value = 127;
            trackBarLabel128.Label = "128";
            trackBarLabel128.Value = 128;
            trackBarLabel129.Label = "129";
            trackBarLabel129.Value = 129;
            trackBarLabel130.Label = "130";
            trackBarLabel130.Value = 130;
            trackBarLabel131.Label = "131";
            trackBarLabel131.Value = 131;
            trackBarLabel132.Label = "132";
            trackBarLabel132.Value = 132;
            trackBarLabel133.Label = "133";
            trackBarLabel133.Value = 133;
            trackBarLabel134.Label = "134";
            trackBarLabel134.Value = 134;
            trackBarLabel135.Label = "135";
            trackBarLabel135.Value = 135;
            trackBarLabel136.Label = "136";
            trackBarLabel136.Value = 136;
            trackBarLabel137.Label = "137";
            trackBarLabel137.Value = 137;
            trackBarLabel138.Label = "138";
            trackBarLabel138.Value = 138;
            trackBarLabel139.Label = "139";
            trackBarLabel139.Value = 139;
            trackBarLabel140.Label = "140";
            trackBarLabel140.Value = 140;
            trackBarLabel141.Label = "141";
            trackBarLabel141.Value = 141;
            trackBarLabel142.Label = "142";
            trackBarLabel142.Value = 142;
            trackBarLabel143.Label = "143";
            trackBarLabel143.Value = 143;
            trackBarLabel144.Label = "144";
            trackBarLabel144.Value = 144;
            trackBarLabel145.Label = "145";
            trackBarLabel145.Value = 145;
            trackBarLabel146.Label = "146";
            trackBarLabel146.Value = 146;
            trackBarLabel147.Label = "147";
            trackBarLabel147.Value = 147;
            trackBarLabel148.Label = "148";
            trackBarLabel148.Value = 148;
            trackBarLabel149.Label = "149";
            trackBarLabel149.Value = 149;
            trackBarLabel150.Label = "150";
            trackBarLabel150.Value = 150;
            trackBarLabel151.Label = "151";
            trackBarLabel151.Value = 151;
            trackBarLabel152.Label = "152";
            trackBarLabel152.Value = 152;
            trackBarLabel153.Label = "153";
            trackBarLabel153.Value = 153;
            trackBarLabel154.Label = "154";
            trackBarLabel154.Value = 154;
            trackBarLabel155.Label = "155";
            trackBarLabel155.Value = 155;
            trackBarLabel156.Label = "156";
            trackBarLabel156.Value = 156;
            trackBarLabel157.Label = "157";
            trackBarLabel157.Value = 157;
            trackBarLabel158.Label = "158";
            trackBarLabel158.Value = 158;
            trackBarLabel159.Label = "159";
            trackBarLabel159.Value = 159;
            trackBarLabel160.Label = "160";
            trackBarLabel160.Value = 160;
            trackBarLabel161.Label = "161";
            trackBarLabel161.Value = 161;
            trackBarLabel162.Label = "162";
            trackBarLabel162.Value = 162;
            trackBarLabel163.Label = "163";
            trackBarLabel163.Value = 163;
            trackBarLabel164.Label = "164";
            trackBarLabel164.Value = 164;
            trackBarLabel165.Label = "165";
            trackBarLabel165.Value = 165;
            trackBarLabel166.Label = "166";
            trackBarLabel166.Value = 166;
            trackBarLabel167.Label = "167";
            trackBarLabel167.Value = 167;
            trackBarLabel168.Label = "168";
            trackBarLabel168.Value = 168;
            trackBarLabel169.Label = "169";
            trackBarLabel169.Value = 169;
            trackBarLabel170.Label = "170";
            trackBarLabel170.Value = 170;
            trackBarLabel171.Label = "171";
            trackBarLabel171.Value = 171;
            trackBarLabel172.Label = "172";
            trackBarLabel172.Value = 172;
            trackBarLabel173.Label = "173";
            trackBarLabel173.Value = 173;
            trackBarLabel174.Label = "174";
            trackBarLabel174.Value = 174;
            trackBarLabel175.Label = "175";
            trackBarLabel175.Value = 175;
            trackBarLabel176.Label = "176";
            trackBarLabel176.Value = 176;
            trackBarLabel177.Label = "177";
            trackBarLabel177.Value = 177;
            trackBarLabel178.Label = "178";
            trackBarLabel178.Value = 178;
            trackBarLabel179.Label = "179";
            trackBarLabel179.Value = 179;
            trackBarLabel180.Label = "180";
            trackBarLabel180.Value = 180;
            trackBarLabel181.Label = "181";
            trackBarLabel181.Value = 181;
            trackBarLabel182.Label = "182";
            trackBarLabel182.Value = 182;
            trackBarLabel183.Label = "183";
            trackBarLabel183.Value = 183;
            trackBarLabel184.Label = "184";
            trackBarLabel184.Value = 184;
            trackBarLabel185.Label = "185";
            trackBarLabel185.Value = 185;
            trackBarLabel186.Label = "186";
            trackBarLabel186.Value = 186;
            trackBarLabel187.Label = "187";
            trackBarLabel187.Value = 187;
            trackBarLabel188.Label = "188";
            trackBarLabel188.Value = 188;
            trackBarLabel189.Label = "189";
            trackBarLabel189.Value = 189;
            trackBarLabel190.Label = "190";
            trackBarLabel190.Value = 190;
            trackBarLabel191.Label = "191";
            trackBarLabel191.Value = 191;
            trackBarLabel192.Label = "192";
            trackBarLabel192.Value = 192;
            trackBarLabel193.Label = "193";
            trackBarLabel193.Value = 193;
            trackBarLabel194.Label = "194";
            trackBarLabel194.Value = 194;
            trackBarLabel195.Label = "195";
            trackBarLabel195.Value = 195;
            trackBarLabel196.Label = "196";
            trackBarLabel196.Value = 196;
            trackBarLabel197.Label = "197";
            trackBarLabel197.Value = 197;
            trackBarLabel198.Label = "198";
            trackBarLabel198.Value = 198;
            trackBarLabel199.Label = "199";
            trackBarLabel199.Value = 199;
            trackBarLabel200.Label = "200";
            trackBarLabel200.Value = 200;
            trackBarLabel201.Label = "201";
            trackBarLabel201.Value = 201;
            trackBarLabel202.Label = "202";
            trackBarLabel202.Value = 202;
            trackBarLabel203.Label = "203";
            trackBarLabel203.Value = 203;
            trackBarLabel204.Label = "204";
            trackBarLabel204.Value = 204;
            trackBarLabel205.Label = "205";
            trackBarLabel205.Value = 205;
            trackBarLabel206.Label = "206";
            trackBarLabel206.Value = 206;
            trackBarLabel207.Label = "207";
            trackBarLabel207.Value = 207;
            trackBarLabel208.Label = "208";
            trackBarLabel208.Value = 208;
            trackBarLabel209.Label = "209";
            trackBarLabel209.Value = 209;
            trackBarLabel210.Label = "210";
            trackBarLabel210.Value = 210;
            trackBarLabel211.Label = "211";
            trackBarLabel211.Value = 211;
            trackBarLabel212.Label = "212";
            trackBarLabel212.Value = 212;
            trackBarLabel213.Label = "213";
            trackBarLabel213.Value = 213;
            trackBarLabel214.Label = "214";
            trackBarLabel214.Value = 214;
            trackBarLabel215.Label = "215";
            trackBarLabel215.Value = 215;
            trackBarLabel216.Label = "216";
            trackBarLabel216.Value = 216;
            trackBarLabel217.Label = "217";
            trackBarLabel217.Value = 217;
            trackBarLabel218.Label = "218";
            trackBarLabel218.Value = 218;
            trackBarLabel219.Label = "219";
            trackBarLabel219.Value = 219;
            trackBarLabel220.Label = "220";
            trackBarLabel220.Value = 220;
            trackBarLabel221.Label = "221";
            trackBarLabel221.Value = 221;
            trackBarLabel222.Label = "222";
            trackBarLabel222.Value = 222;
            trackBarLabel223.Label = "223";
            trackBarLabel223.Value = 223;
            trackBarLabel224.Label = "224";
            trackBarLabel224.Value = 224;
            trackBarLabel225.Label = "225";
            trackBarLabel225.Value = 225;
            trackBarLabel226.Label = "226";
            trackBarLabel226.Value = 226;
            trackBarLabel227.Label = "227";
            trackBarLabel227.Value = 227;
            trackBarLabel228.Label = "228";
            trackBarLabel228.Value = 228;
            trackBarLabel229.Label = "229";
            trackBarLabel229.Value = 229;
            trackBarLabel230.Label = "230";
            trackBarLabel230.Value = 230;
            trackBarLabel231.Label = "231";
            trackBarLabel231.Value = 231;
            trackBarLabel232.Label = "232";
            trackBarLabel232.Value = 232;
            trackBarLabel233.Label = "233";
            trackBarLabel233.Value = 233;
            trackBarLabel234.Label = "234";
            trackBarLabel234.Value = 234;
            trackBarLabel235.Label = "235";
            trackBarLabel235.Value = 235;
            trackBarLabel236.Label = "236";
            trackBarLabel236.Value = 236;
            trackBarLabel237.Label = "237";
            trackBarLabel237.Value = 237;
            trackBarLabel238.Label = "238";
            trackBarLabel238.Value = 238;
            trackBarLabel239.Label = "239";
            trackBarLabel239.Value = 239;
            trackBarLabel240.Label = "240";
            trackBarLabel240.Value = 240;
            trackBarLabel241.Label = "241";
            trackBarLabel241.Value = 241;
            trackBarLabel242.Label = "242";
            trackBarLabel242.Value = 242;
            trackBarLabel243.Label = "243";
            trackBarLabel243.Value = 243;
            trackBarLabel244.Label = "244";
            trackBarLabel244.Value = 244;
            trackBarLabel245.Label = "245";
            trackBarLabel245.Value = 245;
            trackBarLabel246.Label = "246";
            trackBarLabel246.Value = 246;
            trackBarLabel247.Label = "247";
            trackBarLabel247.Value = 247;
            trackBarLabel248.Label = "248";
            trackBarLabel248.Value = 248;
            trackBarLabel249.Label = "249";
            trackBarLabel249.Value = 249;
            trackBarLabel250.Label = "250";
            trackBarLabel250.Value = 250;
            this.trackBarControl2.Properties.Labels.AddRange(new DevExpress.XtraEditors.Repository.TrackBarLabel[] {
            trackBarLabel1,
            trackBarLabel2,
            trackBarLabel3,
            trackBarLabel4,
            trackBarLabel5,
            trackBarLabel6,
            trackBarLabel7,
            trackBarLabel8,
            trackBarLabel9,
            trackBarLabel10,
            trackBarLabel11,
            trackBarLabel12,
            trackBarLabel13,
            trackBarLabel14,
            trackBarLabel15,
            trackBarLabel16,
            trackBarLabel17,
            trackBarLabel18,
            trackBarLabel19,
            trackBarLabel20,
            trackBarLabel21,
            trackBarLabel22,
            trackBarLabel23,
            trackBarLabel24,
            trackBarLabel25,
            trackBarLabel26,
            trackBarLabel27,
            trackBarLabel28,
            trackBarLabel29,
            trackBarLabel30,
            trackBarLabel31,
            trackBarLabel32,
            trackBarLabel33,
            trackBarLabel34,
            trackBarLabel35,
            trackBarLabel36,
            trackBarLabel37,
            trackBarLabel38,
            trackBarLabel39,
            trackBarLabel40,
            trackBarLabel41,
            trackBarLabel42,
            trackBarLabel43,
            trackBarLabel44,
            trackBarLabel45,
            trackBarLabel46,
            trackBarLabel47,
            trackBarLabel48,
            trackBarLabel49,
            trackBarLabel50,
            trackBarLabel51,
            trackBarLabel52,
            trackBarLabel53,
            trackBarLabel54,
            trackBarLabel55,
            trackBarLabel56,
            trackBarLabel57,
            trackBarLabel58,
            trackBarLabel59,
            trackBarLabel60,
            trackBarLabel61,
            trackBarLabel62,
            trackBarLabel63,
            trackBarLabel64,
            trackBarLabel65,
            trackBarLabel66,
            trackBarLabel67,
            trackBarLabel68,
            trackBarLabel69,
            trackBarLabel70,
            trackBarLabel71,
            trackBarLabel72,
            trackBarLabel73,
            trackBarLabel74,
            trackBarLabel75,
            trackBarLabel76,
            trackBarLabel77,
            trackBarLabel78,
            trackBarLabel79,
            trackBarLabel80,
            trackBarLabel81,
            trackBarLabel82,
            trackBarLabel83,
            trackBarLabel84,
            trackBarLabel85,
            trackBarLabel86,
            trackBarLabel87,
            trackBarLabel88,
            trackBarLabel89,
            trackBarLabel90,
            trackBarLabel91,
            trackBarLabel92,
            trackBarLabel93,
            trackBarLabel94,
            trackBarLabel95,
            trackBarLabel96,
            trackBarLabel97,
            trackBarLabel98,
            trackBarLabel99,
            trackBarLabel100,
            trackBarLabel101,
            trackBarLabel102,
            trackBarLabel103,
            trackBarLabel104,
            trackBarLabel105,
            trackBarLabel106,
            trackBarLabel107,
            trackBarLabel108,
            trackBarLabel109,
            trackBarLabel110,
            trackBarLabel111,
            trackBarLabel112,
            trackBarLabel113,
            trackBarLabel114,
            trackBarLabel115,
            trackBarLabel116,
            trackBarLabel117,
            trackBarLabel118,
            trackBarLabel119,
            trackBarLabel120,
            trackBarLabel121,
            trackBarLabel122,
            trackBarLabel123,
            trackBarLabel124,
            trackBarLabel125,
            trackBarLabel126,
            trackBarLabel127,
            trackBarLabel128,
            trackBarLabel129,
            trackBarLabel130,
            trackBarLabel131,
            trackBarLabel132,
            trackBarLabel133,
            trackBarLabel134,
            trackBarLabel135,
            trackBarLabel136,
            trackBarLabel137,
            trackBarLabel138,
            trackBarLabel139,
            trackBarLabel140,
            trackBarLabel141,
            trackBarLabel142,
            trackBarLabel143,
            trackBarLabel144,
            trackBarLabel145,
            trackBarLabel146,
            trackBarLabel147,
            trackBarLabel148,
            trackBarLabel149,
            trackBarLabel150,
            trackBarLabel151,
            trackBarLabel152,
            trackBarLabel153,
            trackBarLabel154,
            trackBarLabel155,
            trackBarLabel156,
            trackBarLabel157,
            trackBarLabel158,
            trackBarLabel159,
            trackBarLabel160,
            trackBarLabel161,
            trackBarLabel162,
            trackBarLabel163,
            trackBarLabel164,
            trackBarLabel165,
            trackBarLabel166,
            trackBarLabel167,
            trackBarLabel168,
            trackBarLabel169,
            trackBarLabel170,
            trackBarLabel171,
            trackBarLabel172,
            trackBarLabel173,
            trackBarLabel174,
            trackBarLabel175,
            trackBarLabel176,
            trackBarLabel177,
            trackBarLabel178,
            trackBarLabel179,
            trackBarLabel180,
            trackBarLabel181,
            trackBarLabel182,
            trackBarLabel183,
            trackBarLabel184,
            trackBarLabel185,
            trackBarLabel186,
            trackBarLabel187,
            trackBarLabel188,
            trackBarLabel189,
            trackBarLabel190,
            trackBarLabel191,
            trackBarLabel192,
            trackBarLabel193,
            trackBarLabel194,
            trackBarLabel195,
            trackBarLabel196,
            trackBarLabel197,
            trackBarLabel198,
            trackBarLabel199,
            trackBarLabel200,
            trackBarLabel201,
            trackBarLabel202,
            trackBarLabel203,
            trackBarLabel204,
            trackBarLabel205,
            trackBarLabel206,
            trackBarLabel207,
            trackBarLabel208,
            trackBarLabel209,
            trackBarLabel210,
            trackBarLabel211,
            trackBarLabel212,
            trackBarLabel213,
            trackBarLabel214,
            trackBarLabel215,
            trackBarLabel216,
            trackBarLabel217,
            trackBarLabel218,
            trackBarLabel219,
            trackBarLabel220,
            trackBarLabel221,
            trackBarLabel222,
            trackBarLabel223,
            trackBarLabel224,
            trackBarLabel225,
            trackBarLabel226,
            trackBarLabel227,
            trackBarLabel228,
            trackBarLabel229,
            trackBarLabel230,
            trackBarLabel231,
            trackBarLabel232,
            trackBarLabel233,
            trackBarLabel234,
            trackBarLabel235,
            trackBarLabel236,
            trackBarLabel237,
            trackBarLabel238,
            trackBarLabel239,
            trackBarLabel240,
            trackBarLabel241,
            trackBarLabel242,
            trackBarLabel243,
            trackBarLabel244,
            trackBarLabel245,
            trackBarLabel246,
            trackBarLabel247,
            trackBarLabel248,
            trackBarLabel249,
            trackBarLabel250});
            this.trackBarControl2.Properties.Maximum = 250;
            this.trackBarControl2.Properties.Minimum = 1;
            this.trackBarControl2.Properties.ShowLabels = true;
            this.trackBarControl2.Properties.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBarControl2.Size = new System.Drawing.Size(418, 50);
            this.trackBarControl2.TabIndex = 7;
            this.trackBarControl2.Value = 1;
            this.trackBarControl2.EditValueChanged += new System.EventHandler(this.trackBarControl2_EditValueChanged);
            // 
            // labelControl1
            // 
            this.labelControl1.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl1.Location = new System.Drawing.Point(268, 22);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(40, 45);
            this.labelControl1.TabIndex = 8;
            this.labelControl1.Text = "占空比:";
            // 
            // labelControl2
            // 
            this.labelControl2.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl2.Location = new System.Drawing.Point(268, 70);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(40, 45);
            this.labelControl2.TabIndex = 9;
            this.labelControl2.Text = "频率:";
            // 
            // labelControl3
            // 
            this.labelControl3.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl3.Location = new System.Drawing.Point(736, 24);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(42, 45);
            this.labelControl3.TabIndex = 10;
            this.labelControl3.Text = "%";
            // 
            // labelControl4
            // 
            this.labelControl4.AutoSizeMode = DevExpress.XtraEditors.LabelAutoSizeMode.None;
            this.labelControl4.Location = new System.Drawing.Point(731, 72);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(47, 43);
            this.labelControl4.TabIndex = 11;
            this.labelControl4.Text = "KHz";
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(795, 373);
            this.Controls.Add(this.labelControl4);
            this.Controls.Add(this.labelControl3);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.trackBarControl2);
            this.Controls.Add(this.trackBarControl1);
            this.Controls.Add(this.gaugeControl1);
            this.Controls.Add(this.chartControl1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Fan Mate GUI";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chartControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.digitalGauge6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.digitalBackgroundLayerComponent1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarControl1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarControl2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarControl2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.Bar bar1;
        private DevExpress.XtraBars.BarSubItem barSubItem2;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.TrackBarControl trackBarControl2;
        private DevExpress.XtraEditors.TrackBarControl trackBarControl1;
        private DevExpress.XtraGauges.Win.GaugeControl gaugeControl1;
        private DevExpress.XtraGauges.Win.Gauges.Digital.DigitalGauge digitalGauge6;
        private DevExpress.XtraGauges.Win.Gauges.Digital.DigitalBackgroundLayerComponent digitalBackgroundLayerComponent1;
        private DevExpress.XtraCharts.ChartControl chartControl1;
        private System.Windows.Forms.Timer timer1;
    }
}

