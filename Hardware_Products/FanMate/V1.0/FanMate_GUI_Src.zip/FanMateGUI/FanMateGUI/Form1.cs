﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using DevExpress.XtraCharts;
using DevExpress.XtraEditors;

namespace FanMateGUI
{
    public partial class Form1 : DevExpress.XtraEditors.XtraForm
    {
        SerialPort sp = new SerialPort();
        List<byte> serialBuffer = new List<byte>();

        public Form1()
        {
            InitializeComponent();

            //Control.CheckForIllegalCrossThreadCalls = false;
        }

        void GetDutyCycle()
        {
            if (sp.IsOpen)
            {
                byte[] data = new byte[2];

                data[0] = (byte)'#';
                data[1] = (byte)'\n';
                sp.Write(data, 0, data.Length);
            }
        }

        void GetFrequence()
        {
            if (sp.IsOpen)
            {
                byte[] data = new byte[2];

                data[0] = (byte)'$';
                data[1] = (byte)'\n';
                sp.Write(data, 0, data.Length);
            }
        }

        void GetRPM()
        {
            if (sp.IsOpen)
            {
                byte[] data = new byte[2];

                data[0] = (byte)'&';
                data[1] = (byte)'\n';
                sp.Write(data, 0, data.Length);
            }
        }

       int pointIndex = 1;
        private void UpdateCharControl(object str)
        {
            if (chartControl1.InvokeRequired)
            {
                Action<string> actionDelegate = (x) =>
                {
                    chartControl1.Series[0].Points.Add(new SeriesPoint(pointIndex++, int.Parse(x.ToString())));
                };
                chartControl1.Invoke(actionDelegate, str);
            }
            else
            {
                chartControl1.Series[0].Points.Add(new SeriesPoint(pointIndex++, int.Parse(str.ToString())));
            }
        }

        private void UpdateGaugeControl(object str)
        {
            if (gaugeControl1.InvokeRequired)
            {
                Action<string> actionDelegate = (x) => { digitalGauge6.Text = x.ToString(); };
                //gaugeControl1.BeginInvoke(actionDelegate);
                gaugeControl1.Invoke(actionDelegate, str);
            }
            else
            {
                digitalGauge6.Text = str.ToString();
            }
        }

        private void UpdateTrackbar1(object str)
        {
            if (trackBarControl1.InvokeRequired)
            {
                Action<string> actionDelegate = (x) => { trackBarControl1.Value = int.Parse(x.ToString()); };
                trackBarControl1.Invoke(actionDelegate, str);
            }
            else
            {
                trackBarControl1.Value = int.Parse(str.ToString());
            }
        }

        private void UpdateTrackbar2(object str)
        {
            if (trackBarControl2.InvokeRequired)
            {
                Action<string> actionDelegate = (x) => { trackBarControl2.Value = int.Parse(x.ToString()); };
                trackBarControl2.Invoke(actionDelegate, str);
            }
            else
            {
                trackBarControl2.Value = int.Parse(str.ToString());
            }
        }

        private void barSubItem2_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            string portName = XtraInputBox.Show("请输入端口号:", "端口设定", string.Empty);
            if (!string.IsNullOrEmpty(portName))
            {
                try
                {
                    sp.PortName = portName;
                    sp.BaudRate = 9600;
                    sp.DataBits = 8;
                    sp.StopBits = StopBits.One;
                    sp.Parity = Parity.None;
                    if (sp.IsOpen) sp.Close();
                    sp.Open();
                    sp.DtrEnable = true;
                    sp.DataReceived += Sp_DataReceived;

                    new Thread(() =>
                    {
                        byte b = 0;
                        int t = 0;
                        bool isDutyCycle = false;
                        bool isFrequence = false;
                        bool isRPM = false;
                        bool isValidByte = false;

                        while (true)
                        {
                            lock (serialBuffer)
                            {
                                if (serialBuffer.Count > 0)
                                {
                                    b = serialBuffer[0];
                                    serialBuffer.RemoveAt(0);
                                    isValidByte = true;
                                }
                            }

                            if (!isValidByte) continue;

                            if (isDutyCycle)
                            {
                                //trackBarControl1.Value = (int)b;
                                UpdateTrackbar1(b.ToString());
                                System.Diagnostics.Debug.WriteLine("duty cycle: " + b.ToString());
                                isDutyCycle = false;
                                isValidByte = false;
                                continue;
                            }

                            if (isFrequence)
                            {
                                //trackBarControl2.Value = (int)b;
                                UpdateTrackbar2(b.ToString());
                                System.Diagnostics.Debug.WriteLine("frequence: " + b.ToString());
                                isFrequence = false;
                                isValidByte = false;
                                continue;
                            }

                            if (isRPM)
                            {
                                t = b << 8;
                                lock (serialBuffer)
                                {
                                    if (serialBuffer.Count > 0)
                                    {
                                        b = serialBuffer[0];
                                        serialBuffer.RemoveAt(0);
                                        t |= b;
                                    }
                                }
                                //digitalGauge6.Text = t.ToString();
                                UpdateGaugeControl(t.ToString());
                                UpdateCharControl(t.ToString());
                                System.Diagnostics.Debug.WriteLine("RPM: " + t.ToString());
                                isRPM = false;
                                isValidByte = false;
                                continue;
                            }

                            switch (b)
                            {
                                case (byte)'#':   //get duty cycle
                                    isDutyCycle = true;
                                    break;
                                case (byte)'$':   //get frequence
                                    isFrequence = true;
                                    break;
                                case (byte)'&':   //get RPM
                                    isRPM = true;
                                    break;
                                default:
                                    break;
                            }
                            isValidByte = false;
                        }
                    }).Start();

                    Thread.Sleep(100);
                    GetDutyCycle();
                    Thread.Sleep(500);
                    GetFrequence();
                    Thread.Sleep(500);
                    GetRPM();
                    Thread.Sleep(100);

                    timer1.Enabled = true;

                    chartControl1.Series.Add("RPM", DevExpress.XtraCharts.ViewType.Line);
                    chartControl1.Series[0].ArgumentScaleType = DevExpress.XtraCharts.ScaleType.Numerical;
                    ((XYDiagram)chartControl1.Diagram).EnableAxisXZooming = true;
                    chartControl1.Legend.Visibility = DevExpress.Utils.DefaultBoolean.False;
                }
                catch (Exception ex)
                {
                    XtraMessageBox.Show(ex.Message, "串口异常");
                }
            }
        }

        private void Sp_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            int len = sp.BytesToRead;
            byte[] data = new byte[len];
            sp.Read(data, 0, data.Length);
            lock (serialBuffer)
            {
                serialBuffer.AddRange(data);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void trackBarControl1_EditValueChanged(object sender, EventArgs e)
        {
            if (sp.IsOpen)
            {
                string str = "!" + trackBarControl1.Value.ToString();
                sp.WriteLine(str);
                labelControl3.Text = trackBarControl1.Value.ToString() + "%";
            }
        }

        private void trackBarControl2_EditValueChanged(object sender, EventArgs e)
        {
            if (sp.IsOpen)
            {
                string str = "@" + trackBarControl2.Value.ToString();
                sp.WriteLine(str);
                labelControl4.Text = trackBarControl2.Value.ToString() + "KHz";
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            GetRPM();
        }
    }
}
